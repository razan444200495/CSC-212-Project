
package photoapp;
public class Test {
    public static void main(String[] args) {
        PhotoManager manager = new PhotoManager();
        InvIndexPhotoManager indexManager = new InvIndexPhotoManager();

        // Add sample photos
        Photo img1 = new Photo("hedgehog.jpg", toTagList("animal, hedgehog, apple, grass, green"));
        manager.addPhoto(img1);
        indexManager.addPhoto(img1);

        Photo img2 = new Photo("bear.jpg", toTagList("animal, bear, cab, grass, wind"));
        manager.addPhoto(img2);
        indexManager.addPhoto(img2);

        Photo img3 = new Photo("orange-butterfly.jpg", toTagList("insect, butterfly, flower, color"));
        manager.addPhoto(img3);
        indexManager.addPhoto(img3);

        // Create albums
        Album album1 = new Album("Bears Only", "bear", manager);
        Album album2 = new Album("Animals with Grass", "animal AND grass", manager);
        Album album3 = new Album("All Photos", "", manager);

        // Display album contents
        displayAlbum(album1);
        displayAlbum(album2);
        displayAlbum(album3);

        // Test photo deletion
        System.out.println("\nDeleting 'bear.jpg'...\n");
        manager.deletePhoto("bear.jpg");

        // Check album again after deletion
        Album updatedAlbum = new Album("After Deletion", "", manager);
        displayAlbum(updatedAlbum);
    }

    // Utility: Convert string of tags into LinkedList
    private static LinkedList<String> toTagList(String tagLine) {
        LinkedList<String> result = new LinkedList<>();
        String[] parts = tagLine.split("\\s*,\\s*");
        for (String tag : parts) {
            result.insert(tag);
        }
        return result;
    }

    // Utility: Print all photo paths in album
    private static void displayAlbum(Album a) {
        System.out.println("\nAlbum: " + a.getName());
        System.out.println("Condition: " + a.getCondition());
        LinkedList<Photo> imgs = a.getPhotos();

        if (imgs.empty()) {
            System.out.println("No matching photos.");
            return;
        }

        imgs.findFirst();
        while (!imgs.last()) {
            System.out.println("- " + imgs.retrieve().getPath());
            imgs.findNext();
        }
        System.out.println("- " + imgs.retrieve().getPath());

        System.out.println("Comparisons: " + a.getNbComps());
    }
}
